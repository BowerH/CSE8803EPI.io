# CSE-8803-EPI-Project: MRSA Infection Prediction

## Overview

This package provides a machine learning pipeline for predicting MRSA (methicillin-resistant Staphylococcus aureus) infection rates across California counties and hospital facility types. The models integrate Social Determinants of Health (SDOH) data with hospital-level infection records to generate county-level and facility-specific predictions.

## Features

- **Multi-model evaluation** - Linear Regression, ARIMA, Random Forest, XGBoost, Deep Learning
- **SDOH feature analysis** - Temporal stability assessment and correlation studies
- **Hyperparameter optimization** - RandomizedSearchCV with rolling-horizon validation
- **Per-facility predictions** - Hospital-type-specific infection forecasts
- **Feature importance interpretation** - Explainable model outputs for key drivers

## Installation

### 1. Extract the Archive
```bash
tar -xzf CSE-8803-EPI-Project.tar.gz
cd CSE-8803-EPI-Project
```

### 2. Activate the Environment
With Rye pre-installed, the environment is ready to use:
```bash
source .venv/bin/activate  # On Windows: .venv\Scripts\activate
```

## How to Use

The package contains notebooks organized in `src/cse_8803_epi_project/code/`:

### Key Notebooks
1. **`modeling/model_testing.ipynb`**
   - Comprehensive model training and evaluation
   - Compares 8 different model architectures
   - Hyperparameter tuning and rolling-horizon validation
   - Feature importance analysis
   - **Pre-computed results** available in `data/report_data/`

2. **`modeling/sdoh_eda.ipynb`**
   - Exploratory analysis of SDOH variables
   - Correlation analysis, PCA, temporal stability assessment
   - Insights into key socioeconomic health factors

**Data Processing (Optional - Already Complete):**
- `data_processing/sdoh_preprocessing.py`
- `data_processing/mrsa_preprocessing.ipynb`
- `data_processing/sdoh_mrsa_join.ipynb`
- `data_processing/mrsa_county-year_processing.ipynb`

> Note: Data processing has already been completed. These files are included for reference if you need to regenerate data from raw sources. Each notebook contains headers explaining its inputs and outputs.

### Modeling Results (Pre-computed)

All key results are available in `data/report_data/`:
- `all_hospital_results.csv` - Model performance metrics and comparisons
- `final_facilities_df.csv` - Per-hospital-type performance
- `pred_2024_rf_sdoh_lag.csv` - 2024 predictions
- `pred_2025_rf_sdoh_lag.csv` - 2025 predictions


## Key Input Files

**Location:** `src/cse_8803_epi_project/data/`

### MRSA Data
- `raw_data/` - Annual MRSA infection reports (2015-2024)
- `clean_data/county-year_mrsa.csv` - Aggregated by county and year

### SDOH Data
- `raw_data/` - State health factor rankings and measures
- `clean_data/combined_measure_data.csv` - Merged SDOH variables (2017-2024)


## Requirements

- Python 3.8+
- `pandas`, `numpy`
- `scikit-learn`
- `xgboost`
- `tensorflow`/`keras`
- `statsmodels` (for ARIMA)
- `matplotlib`, `seaborn` (for visualizations)
- `jupyter` (for notebook execution)

See `requirements.txt` for pinned versions.


## Project Info

- **Project:** CSE-8803-EPI-Project
- **Repository:** https://github.com/alanwang20/CSE-8803-EPI-Project
- **Owner:** alanwang20
- **Branch:** main

For questions or additional analysis, refer to the repository's issue tracker or contact the project owner.
