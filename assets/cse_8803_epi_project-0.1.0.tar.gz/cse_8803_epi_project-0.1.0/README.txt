================================================================================
                    CSE-8803-EPI-Project: MRSA Infection Prediction
================================================================================

OVERVIEW
--------
This package provides a machine learning pipeline for predicting MRSA (methicillin-resistant 
Staphylococcus aureus) infection rates across California counties and hospital facility types. 
The models integrate Social Determinants of Health (SDOH) data with hospital-level infection 
records to generate county-level and facility-specific predictions.

FEATURES
--------
- Multi-model evaluation (Linear Regression, ARIMA, Random Forest, XGBoost, Deep Learning)
- SDOH feature analysis and temporal stability assessment
- Hyperparameter optimization and rolling-horizon validation
- Per-facility and county-level infection predictions
- Feature importance interpretation for model explainability


INSTALLATION
-------------
1. Extract the archive:
   tar -xzf CSE-8803-EPI-Project.tar.gz
   cd CSE-8803-EPI-Project

2. Activate the environment:
   source .venv/bin/activate  # On Windows: .venv\Scripts\activate

Note: Rye and all dependencies are pre-installed in the package.


HOW TO USE
----------
The package contains notebooks in src/cse_8803_epi_project/code/modeling/:

KEY NOTEBOOKS:

  1. model_testing.ipynb
     - Comprehensive model training and evaluation
     - Compares 8 different model architectures
     - Hyperparameter tuning and rolling-horizon validation
     - Feature importance analysis
     - Pre-computed results available in data/report_data/
     
  2. sdoh_eda.ipynb
     - Exploratory analysis of SDOH variables
     - Correlation analysis, PCA, and temporal stability
     - Insights into key socioeconomic health factors

DATA PROCESSING (Optional - Already Complete):
  These files are included for reference if regenerating from raw data:
  
  - data_processing/sdoh_preprocessing.py
  - data_processing/mrsa_preprocessing.ipynb
  - data_processing/sdoh_mrsa_join.ipynb
  - data_processing/mrsa_county-year_processing.ipynb
  
  Each notebook contains headers explaining its inputs and outputs.



PRE-COMPUTED OUTPUT RESULTS:
  all_hospital_results.csv
    - Performance metrics (MAE, RMSE, R²) for all 8 models
    - Overall/county-level infection predictions

  final_facilities_df.csv
    - Per-hospital-type performance metrics

  pred_2024_rf_sdoh_lag.csv, pred_2025_rf_sdoh_lag.csv
    - County-level infection predictions for 2024 and 2025


KEY DATA FILES: 
Location: src/cse_8803_epi_project/data/

MRSA Data:
  - raw_data/: Annual MRSA infection reports (2015-2024)
  - clean_data/county-year_mrsa.csv: Aggregated by county and year

SDOH Data:
  - raw_data/: State health factor rankings and measures
  - clean_data/combined_measure_data.csv: Merged SDOH variables (2017-2024)

Reports:
  - all_hospital_results.csv: Model performance comparison
  - final_facilities_df.csv: Per-facility model metrics
  - pred_2024_rf_sdoh_lag.csv: 2024 predictions


REQUIREMENTS
------------
- Python 3.8+
- pandas, numpy
- scikit-learn
- xgboost
- tensorflow/keras
- statsmodels (for ARIMA)
- matplotlib, seaborn (for visualizations)
- jupyter (for notebook execution)

See requirements.txt for pinned versions.



CONTACT & CITATION
-------------------
Project: CSE-8803-EPI-Project
Repository: https://github.com/alanwang20/CSE-8803-EPI-Project
Branch: main

For questions or issues, refer to the repository's issue tracker.

================================================================================
