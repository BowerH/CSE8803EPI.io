import argparse
from pathlib import Path
import pandas as pd
import re

'''
To run:
1. Install the required packages: `pip install pandas openpyxl`
2. Place the input Excel files in the `data` directory.
3. Run this script: `python attribute_filter.py`
4. The filtered output will be saved in the `data/cleaned_attributes` directory.

cmd line:
python src/cse_8803_epi_project/code/data_processing/sdoh_preprocessing.py src/cse_8803_epi_project/data/sdoh_data/raw_data/ -o src/cse_8803_epi_project/data/sdoh_data/clean_data/
'''
# -----------------------------
# Configuration
# -----------------------------
RANKED_SHEET = "Ranked Measure Data"
ADDITIONAL_SHEET = "Additional Measure Data"
DROP_SUBSTRINGS = ["95% CI - Low", "95% CI - High", "Z-Score"]

ID_COLS = ["Year", "FIPS", "County", "State"]

FEATURE_COLS = [
    "Population", "% rural", "% Less Than 18 Years of Age", "% 65 and Over",
    "% Black", "% Hispanic", "% Asian", "% American Indian & Alaska Native",
    "% Non-Hispanic white", "% Not Proficient in English", "% female",
    "% Completed High School", "% Some College", "High School Graduation Rate",
    "Spending per-pupil", "Average Grade Performance", "% Enrolled in Free or Reduced Lunch",
    "Median Household Income", "Income Ratio", "20th Percentile Income", "80th Percentile Income",
    "% Children in Poverty", "% Children in Single-Parent Households",
    "% Severe Housing Cost Burden", "% Severe Housing Problems",
    "% Homeowners", "% Broadband Access", "Overcrowding", "Inadequate Facilities",
    "% Unemployed", "Labor Force", "Women's Median Earnings", "Men's Median Earnings", "Gender Pay Gap",
    "% Smokers", "% Adults with Obesity", "% Physically Inactive",
    "% With Access to Exercise Opportunities", "% Excessive Drinking",
    "% Uninsured", "Primary Care Physicians Rate", "Dentist Rate", "Mental Health Provider Rate",
    "Other Primary Care Provider Rate", "% With Annual Mammogram", "% Vaccinated",
    "Social Association Rate", "Segregation Index", "Violent Crime Rate",
    "Average Daily PM2.5", "Presence of Water Violation",
    "% Drive Alone to Work", "% Long Commute - Drives Alone",
    "Injury Death Rate", "Drug Overdose Mortality Rate", "Homicide Rate", "Suicide Rate (Age-Adjusted)"
]

NORMALIZE_CASE = True

# -----------------------------
# Utilities
# -----------------------------
def extract_year_from_filename(filename: str) -> str:
    m = re.search(r"\b(20\d{2})\b", filename)
    return m.group(1) if m else ""

def normalize_col(name: str) -> str:
    n = str(name).strip()
    return n.lower() if NORMALIZE_CASE else n

def build_name_map(columns) -> dict:
    return {normalize_col(c): c for c in columns}

def select_existing(df: pd.DataFrame, desired: list) -> list:
    name_map = build_name_map(df.columns)
    selected = []
    for want in desired:
        key = normalize_col(want)
        if key in name_map:
            selected.append(name_map[key])
    return selected

def drop_unwanted_columns(df: pd.DataFrame) -> pd.DataFrame:
    def keep(col: str) -> bool:
        name = str(col)
        return not any(s.lower() in name.lower() for s in DROP_SUBSTRINGS)
    return df[[c for c in df.columns if keep(c)]]

def find_unreliable_columns(df: pd.DataFrame) -> list:
    cols = []
    for c in df.columns:
        if re.fullmatch(r"\s*Unreliable(\.\d+)?\s*", str(c), flags=re.IGNORECASE):
            cols.append(c)
    return cols

def remove_unreliable_rows(df: pd.DataFrame) -> pd.DataFrame:
    unreliable_cols = find_unreliable_columns(df)
    if not unreliable_cols:
        return df
    mask = pd.Series(True, index=df.index)
    for col in unreliable_cols:
        col_str = df[col].astype(str)
        is_blank = df[col].isna() | (col_str.str.strip() == "")
        mask &= is_blank
    return df[mask]

def read_sheet_case_insensitive(xlsx_path: Path, target_name: str) -> pd.DataFrame:
    xls = pd.ExcelFile(xlsx_path)
    if target_name in xls.sheet_names:
        return pd.read_excel(xlsx_path, sheet_name=target_name, engine="openpyxl")
    matches = [s for s in xls.sheet_names if s.lower() == target_name.lower()]
    if not matches:
        raise KeyError(f"Sheet '{target_name}' not found in {xlsx_path.name}. "
                       f"Available sheets: {', '.join(xls.sheet_names)}")
    return pd.read_excel(xlsx_path, sheet_name=matches[0], engine="openpyxl")

def clean_and_filter(df: pd.DataFrame, year: str) -> pd.DataFrame:
    df = drop_unwanted_columns(df)
    df = remove_unreliable_rows(df)
    if "Year" in df.columns:
        df = df.drop(columns=["Year"])
    df.insert(0, "Year", year)
    keep = select_existing(df, ID_COLS + FEATURE_COLS)
    if not keep:
        keep = select_existing(df, ["Year", "FIPS", "County", "State"])
    return df[keep]

def export_sheets(xlsx_path: Path, out_dir: Path):
    out_dir.mkdir(parents=True, exist_ok=True)
    year = extract_year_from_filename(xlsx_path.name)
    ranked_df = read_sheet_case_insensitive(xlsx_path, RANKED_SHEET)
    additional_df = read_sheet_case_insensitive(xlsx_path, ADDITIONAL_SHEET)
    ranked_df = clean_and_filter(ranked_df, year)
    additional_df = clean_and_filter(additional_df, year)
    ranked_csv = out_dir / f"{year}_ranked_measure_data.csv"
    additional_csv = out_dir / f"{year}_additional_measure_data.csv"
    ranked_df.to_csv(ranked_csv, index=False)
    additional_df.to_csv(additional_csv, index=False)
    print(f"Exported CSVs for {xlsx_path.name}")
    ranked_df_out = ranked_df.copy()
    ranked_df_out.insert(1, "Sheet", "Ranked")
    additional_df_out = additional_df.copy()
    additional_df_out.insert(1, "Sheet", "Additional")
    return ranked_df_out, additional_df_out

def process_folder(folder: Path, out_dir: Path) -> None:
    folder = Path(folder)
    excel_files = sorted(folder.glob("*.xlsx"))
    if not excel_files:
        print(f"No Excel files found in {folder}")
        return
    combined_frames = []
    for xlsx in excel_files:
        try:
            ranked_df, additional_df = export_sheets(xlsx, out_dir)
            combined_frames.extend([ranked_df, additional_df])
        except Exception as e:
            print(f"Error processing {xlsx.name}: {e}")
    if combined_frames:
        combined = pd.concat(combined_frames, ignore_index=True, sort=False)
        combined_out = out_dir / "combined_attributes_all_years.csv"
        combined.to_csv(combined_out, index=False)
        print(f"Combined CSV written to: {combined_out}")

# -----------------------------
# CLI
# -----------------------------
if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Export Ranked/Additional Measure sheets (2017–2024) to CSVs and combine into one file."
    )
    parser.add_argument("input_dir", type=str, help="Directory containing yearly Excel files")
    parser.add_argument("-o", "--out-dir", type=str, default="./exports", help="Output directory for CSV files")
    args = parser.parse_args()
    process_folder(Path(args.input_dir), Path(args.out_dir))